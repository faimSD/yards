"""
yards v2 is a class version of the original yards program.

Script to generate pseudo-random artificial data for games.
Uses distribution curves to place sprites and create bounding boxes.

@authors: Jaden Kim & Chanha Kim
"""

# modules
import os
import glob
import shutil
import yaml
import tqdm
from PIL import Image, ImageDraw
from numpy.random import choice
from .tools import _helper # import the helper module correctly


class yards():

    def __init__(self, config_path = None):
        if config_path != None:
            self.load_config_from_file(config_path)
        else:
            self._config_path = None
            self._config = None
            self._dirs = None
            self._params = None
            self._classes = None
            self._class_numbers = None
            self._output_dirs = None
            self._map_path_cache = None
            self._sprite_path_cache = None

    # Setting configurations and getters/setters

    def _create_output_dirs(self):
        if os.path.isdir(self._dirs['output']):
            shutil.rmtree(self._dirs['output'])
            os.mkdir(self._dirs['output'])

        os.mkdir(self._dirs['output'] +'images/')
        os.mkdir(self._dirs['output'] +'labels/')

        self._output_dirs = {
            'images_train': self._dirs['output'] + 'images/train/',
            'images_val': self._dirs['output'] + 'images/val/',
            'labels_train': self._dirs['output'] + 'labels/train/',
            'labels_val': self._dirs['output'] + 'labels/val/'
        }
        for out in self._output_dirs.values(): os.mkdir(out)

    def _parse_params(self):
        """Parses all_params dictionary into separate dictionaries"""
        self.set_directories(self._config['directories'])
        self.set_parameters(self._config['parameters'])
        self.set_classes(self._config['classes'])

    def _cache_paths(self):
        self._map_path_cache = glob.glob(self._dirs['maps']+'*.png')
        self._sprite_path_cache = {}
        for c in self._classes:
            self._sprite_path_cache[c] = glob.glob(self._dirs['sprites']+'{}/*.png'.format(c))

    def load_config_from_file(self, config_path):
        self._config_path = config_path
        with open(r'{}'.format(self._config_path)) as file:
            self._config = yaml.load(file, Loader=yaml.FullLoader)
        self._parse_params()
        self._create_output_dirs()

    def _valid_config(config):
        return True

    def set_config(self, config):
        if self._valid_config(config):
            self._config = config
            self._parse_params()
            self._create_output_dirs()
        else:
            print('Configuration is not valid.')

    def get_config(self): return self._config

    def _valid_directories(self, paths):
        return True

    def set_directories(self, paths):
        if self._valid_directories(paths):
            self._dirs = paths
        else:
            print('Directories are not valid')

    def get_directories(self): return self._dirs

    def _valid_parameters(self, parameters):
        return True

    def set_parameters(self, parameters):
        if self._valid_parameters(parameters):
            self._params = parameters
            if not self._params['label_all_classes']:
                for c in self._classes:
                    if c not in self._params['labeled_classes']:
                        self._class_numbers[c] = -1
        else:
            print('Parameters are not valid')

    def get_parameters(self): return self._parameters

    def _valid_classes(self, classes):
        return True

    def set_classes(self, classes):
        if self._valid_classes(classes):
            self._classes = classes
            self._class_numbers = {c: n for (c, n) in list(zip(self._classes, [i for i in range(len(self._classes))]))}
        
            if self._params != None:
                if not self._params['label_all_classes']:
                    for c in self._classes:
                        if c not in self._params['labeled_classes']:
                            self._class_numbers[c] = -1
            else:
                print("You haven't loaded the parameters yet. If you're labeling select classes, then load parameters first before loading classes.")

            if self._dirs != None:
                self._cache_paths()
            else:
                print("You haven't loaded the directory paths yet. Load the directories first before loading the classes.")

        else:
            print('Classes are not valid.')

    def get_classes(self): return self._classes

    def _create_image(self, count, output_dir):
        background_image = Image.open(choice(self._map_path_cache))
        new_image = background_image.copy().convert('RGBA')
        map_dim = new_image.size
        background_image.close()

        # get the sprite paths
        sprite_paths = _helper._gather_sprite_paths(self._sprite_path_cache, (self._classes, self._class_numbers), self._params['classification_scheme'], self._params['max_sprites_per_image'])
        bbox_cache = []

        # add the sprites to the new image, saving the bounding box information in a cache
        for sprite_path in sprite_paths:
            sprite = Image.open(sprite_path).convert('RGBA')
            if self._params['transform_sprites']:
                sprite = _helper._transform_sprite(sprite, map_dim)
            sprite_dim = sprite.size

            sprite_pos, is_sprite_clipped = _helper._get_sprite_pos(map_dim, sprite_dim, self._params['clip_sprites'])
            if is_sprite_clipped:
                sprite, sprite_dim, sprite_pos = _helper._edge_handler(map_dim, sprite_dim, sprite_pos, sprite)

            new_image = _helper._draw_sprite_to_background(sprite, new_image, sprite_pos)
            sprite.close()
            bbox = _helper._get_bbox(map_dim, sprite_dim, sprite_pos)
            if sprite_paths[sprite_path] != -1:
                bbox_cache.append((sprite_paths[sprite_path], *bbox))

        # save and close the image
        new_image.save('{}{}.png'.format(output_dir, count))
        new_image.close()

        # return the cache
        return bbox_cache

    def _create_annotation(self, bbox_cache, count, output_dir):
        """Creates a dataset label at the desired directory."""
        with open('{}{}.txt'.format(output_dir, count), 'w') as file:
            for bbox in bbox_cache:
                file.write('{} {} {} {} {}\n'.format(*bbox))

    def loop(self):
        """Creates the images."""
        num_train = self._params['num_images'] * self._params['train_size']
        print('Writing {} images.'.format(self._params['num_images']))
        for count in tqdm.tqdm(range(1, self._params['num_images']+1)):
            bbox_cache = self._create_image(count, self._output_dirs['images_train'] if count <= num_train else self._output_dirs['images_val'])
            self._create_annotation(bbox_cache, count, self._output_dirs['labels_train'] if count <= num_train else self._output_dirs['labels_val'])
        print('Finished writing {} images.'.format(self._params['num_images']))

    def visualize(self, directory='train', num_visualize=50):
        """Draws bounding boxes around the images."""
        if directory == 'train':
            image_dir = self._output_dirs['images_train']
            label_dir = self._output_dirs['labels_train']
        elif directory == 'label':
            image_dir = directory['images']
            label_dir = directory['labels']

        examples_dir = self._dirs['output']+'examples/'
        if os.path.isdir(examples_dir):
            shutil.rmtree(examples_dir)
        os.mkdir(examples_dir)

        image_paths = glob.glob(image_dir+'*.png')[0:num_visualize]

        print('Visualizing {} example images.'.format(num_visualize))
        for i in tqdm.tqdm(range(len(image_paths))):
            bboxes = []
            image_name = os.path.splitext(os.path.split(image_paths[i])[1])[0]
            with open(label_dir+'{}.txt'.format(image_name)) as file:
                for line in file:
                    line = [float(i) for i in line.split()]
                    bboxes.append(line)
            image = Image.open(image_paths[i])
            draw = ImageDraw.Draw(image)
            for bbox in bboxes:
                # class_number = int(bbox[0])
                x1 = int(image.size[0]*bbox[1] - image.size[0]*bbox[3]/2)
                y1 = int(image.size[1]*bbox[2] - image.size[1]*bbox[4]/2)
                x2 = int(image.size[0]*bbox[1] + image.size[0]*bbox[3]/2)
                y2 = int(image.size[1]*bbox[2] + image.size[1]*bbox[4]/2)
                draw.rectangle([x1, y1, x2, y2], fill=None, outline='red')

            image.save(examples_dir+'annotated-{}.png'.format(image_name))
            image.close()
        print('Finished visualizing {} example images.'.format(num_visualize))


