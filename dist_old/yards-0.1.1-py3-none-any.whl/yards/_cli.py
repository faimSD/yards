"""
_cli.py is the command-line program for that the user can use to generate pseudo-random artificial data for games.

@author: Jaden Kim & Chanha Kim
"""
import argparse
from .yards import yards

# get arguments
def _get_args():
    """Parses and returns command-line arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', '-c',
        type=str,
        default=None,
        required=True,
        help='The path to the config.yaml file.'
    )
    parser.add_argument('--visualize', '-v',
        type=int,
        default=0,
        required=False,
        help='Whether or not to visualize the output.'
    )
    
    return parser.parse_args()

def main():
    args = _get_args()

    if args.config != None:
        yd = yards(args.config)
        yd.loop()

    if args.visualize > 0:
        yd.visualize(num_visualize=args.visualize)




