"""
"validator modules that validates packages"
@author: Jaden Kim & Chanha Kim
@date  : 7/20/2020
"""

def validate_config(config):
    '''Returns true if the config is valid'''
    return True


def validate_directories(paths):
    '''Returns true if the directory paths are valid'''
    return True


def validate_parameters(parameters):
    '''Returns true if the parameters are valid'''
    return True


def validate_classes(classes):
    '''Returns true if the classes are valid'''
    return True

