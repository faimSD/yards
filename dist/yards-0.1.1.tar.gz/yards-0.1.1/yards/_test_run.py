import yards

yd = yards('/Users/chanhakim/Projects/faim_lab/projects/sprite-detection/yards_package/config.yaml')
yd.parallel_loop()
yd.visualize(100)